import { Injectable } from '@angular/core';
import { HttpHeaders, HttpClient } from '@angular/common/http';

@Injectable({
providedIn: 'root'
})
export class SpotifyService {

  getHeader(query: string) {
    const url = 'https://api.spotify.com/v1/' + query;
    let headers = new HttpHeaders();
    headers = headers.append(
      'Authorization',

      "Bearer BQAipgLiCbwV7VmI1aELcYLUnxhDC7Oo6udHyvfKS2v7s5ZzFnxUW6qzX2Tp-IRTmz7kZzATmESaCogByAkLN4IC9OvbFvGUiSVICTomaY94hRjUEcjXQre4nPKAa19NV14UlBMzrtkqOXtHz05Ex73xBwuAmEM"
      );
    return this._http.get(url, { headers });
  }
  // tslint:disable-next-line: variable-name
  constructor(private _http: HttpClient) {}

  searchMusic(str: string, type = 'artist') {
    const param = '&offset=0' + '&limit=20' + '&type=' + type + '&market-US';
    const query = 'search?query=' + str + param;
    return this.getHeader (query);
  }

}


